import 'dart:math' as math;

import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:path/path.dart' as path;
import 'package:sqflite/sqflite.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const BubbleFinanceApp());
}

const ink = Color(0xFF242822);
const paper = Color(0xFFF7F6F1);
const green = Color(0xFF5D9B75);
const coral = Color(0xFFE58F80);
const muted = Color(0xFF85877F);
const palette = <Color>[
  Color(0xFF5D9B75),
  Color(0xFFE58F80),
  Color(0xFFE8C979),
  Color(0xFF8FAED5),
  Color(0xFFB7A0D6),
  Color(0xFF8CCBC4),
];

String money(int amount) {
  final digits = amount.abs().toString();
  final out = StringBuffer();
  for (var i = 0; i < digits.length; i++) {
    if (i > 0 && (digits.length - i) % 3 == 0) out.write('.');
    out.write(digits[i]);
  }
  return '${amount < 0 ? '-' : ''}Rp$out';
}

String compactMoney(int amount) {
  if (amount >= 1000000) return 'Rp${(amount / 1000000).toStringAsFixed(1)}jt';
  if (amount >= 1000) return 'Rp${(amount / 1000).round()}rb';
  return money(amount);
}

class TransactionEntry {
  const TransactionEntry({
    this.id,
    required this.type,
    required this.amount,
    required this.category,
    required this.account,
    required this.date,
    this.note = '',
  });

  final int? id;
  final String type;
  final int amount;
  final String category;
  final String account;
  final String date;
  final String note;

  bool get isIncome => type == 'income';

  Map<String, Object?> toMap() => {
        'type': type,
        'amount': amount,
        'category': category,
        'account': account,
        'date': date,
        'note': note,
      };

  factory TransactionEntry.fromMap(Map<String, Object?> map) => TransactionEntry(
        id: map['id'] as int,
        type: map['type'] as String,
        amount: map['amount'] as int,
        category: map['category'] as String,
        account: map['account'] as String,
        date: map['date'] as String,
        note: (map['note'] as String?) ?? '',
      );
}

class FinanceDatabase {
  FinanceDatabase._();
  static final FinanceDatabase instance = FinanceDatabase._();
  Database? _database;

  Future<Database> get database async {
    if (_database != null) return _database!;
    final dbPath = path.join(await getDatabasesPath(), 'bubble_finance.db');
    _database = await openDatabase(
      dbPath,
      version: 1,
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE transactions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            type TEXT NOT NULL CHECK(type IN ('income', 'expense')),
            amount INTEGER NOT NULL CHECK(amount > 0),
            category TEXT NOT NULL,
            account TEXT NOT NULL,
            date TEXT NOT NULL,
            note TEXT NOT NULL DEFAULT ''
          )
        ''');
        await db.execute('CREATE INDEX idx_transactions_date ON transactions(date)');
      },
    );
    return _database!;
  }

  Future<List<TransactionEntry>> all() async {
    final db = await database;
    final rows = await db.query('transactions', orderBy: 'date DESC, id DESC');
    return rows.map(TransactionEntry.fromMap).toList();
  }

  Future<void> insert(TransactionEntry entry) async {
    final db = await database;
    await db.insert('transactions', entry.toMap());
  }

  Future<void> delete(int id) async {
    final db = await database;
    await db.delete('transactions', where: 'id = ?', whereArgs: [id]);
  }
}

class BubbleFinanceApp extends StatelessWidget {
  const BubbleFinanceApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'bubble. finance',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          useMaterial3: true,
          scaffoldBackgroundColor: paper,
          colorScheme: ColorScheme.fromSeed(seedColor: green),
          appBarTheme: const AppBarTheme(backgroundColor: paper, foregroundColor: ink),
          inputDecorationTheme: InputDecorationTheme(
            filled: true,
            fillColor: Colors.white,
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
            contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          ),
        ),
        home: const DashboardPage(),
      );
}

class DashboardPage extends StatefulWidget {
  const DashboardPage({super.key});
  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  List<TransactionEntry> entries = [];
  bool loading = true;

  @override
  void initState() {
    super.initState();
    reload();
  }

  Future<void> reload() async {
    final data = await FinanceDatabase.instance.all();
    if (!mounted) return;
    setState(() {
      entries = data;
      loading = false;
    });
  }

  int get income => entries.where((e) => e.isIncome).fold(0, (sum, e) => sum + e.amount);
  int get expense => entries.where((e) => !e.isIncome).fold(0, (sum, e) => sum + e.amount);
  int get balance => income - expense; // Add account opening balances when account management is implemented.

  Map<String, int> get categoryTotals {
    final result = <String, int>{};
    for (final entry in entries.where((e) => !e.isIncome)) {
      result.update(entry.category, (value) => value + entry.amount, ifAbsent: () => entry.amount);
    }
    return result;
  }

  Future<void> addEntry() async {
    final saved = await Navigator.of(context).push<bool>(MaterialPageRoute(builder: (_) => const QuickInputPage()));
    if (saved == true) await reload();
  }

  void showDetails(TransactionEntry entry) {
    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      backgroundColor: paper,
      builder: (sheetContext) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(24, 8, 24, 24),
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(entry.category, style: const TextStyle(fontSize: 23, fontWeight: FontWeight.w900, color: ink)),
            const SizedBox(height: 8),
            Text('${entry.isIncome ? '+' : '−'}${money(entry.amount)}', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900, color: entry.isIncome ? green : coral)),
            const Divider(height: 28),
            detailRow('Jenis', entry.isIncome ? 'Masuk' : 'Keluar'),
            detailRow('Akun', entry.account),
            detailRow('Tanggal', entry.date),
            if (entry.note.isNotEmpty) detailRow('Catatan', entry.note),
            const SizedBox(height: 12),
            SizedBox(width: double.infinity, child: OutlinedButton.icon(
              onPressed: entry.id == null ? null : () async {
                await FinanceDatabase.instance.delete(entry.id!);
                if (!mounted) return;
                Navigator.pop(sheetContext);
                await reload();
              },
              icon: const Icon(Icons.delete_outline_rounded), label: const Text('Hapus transaksi'),
            )),
          ]),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          title: const Text('bubble.', style: TextStyle(fontSize: 27, fontWeight: FontWeight.w900, letterSpacing: -1.2)),
          actions: [IconButton(onPressed: reload, icon: const Icon(Icons.refresh_rounded)), const SizedBox(width: 8)],
        ),
        floatingActionButton: FloatingActionButton.extended(
          onPressed: addEntry,
          backgroundColor: ink,
          foregroundColor: Colors.white,
          icon: const Icon(Icons.add_rounded),
          label: const Text('Catat', style: TextStyle(fontWeight: FontWeight.w800)),
        ),
        body: loading
            ? const Center(child: CircularProgressIndicator())
            : RefreshIndicator(
                onRefresh: reload,
                child: ListView(padding: const EdgeInsets.fromLTRB(20, 4, 20, 100), children: [
                  const Text('TOTAL SALDO', style: TextStyle(color: muted, fontSize: 11, letterSpacing: 1.5, fontWeight: FontWeight.w700)),
                  const SizedBox(height: 5),
                  Text(money(balance), style: const TextStyle(fontSize: 34, fontWeight: FontWeight.w900, letterSpacing: -1.2, color: ink)),
                  const SizedBox(height: 20),
                  Row(children: [
                    Expanded(child: SummaryCard(label: '↗  Masuk', amount: income, color: green)),
                    const SizedBox(width: 12),
                    Expanded(child: SummaryCard(label: '↘  Keluar', amount: expense, color: coral)),
                  ]),
                  const SizedBox(height: 28),
                  const SectionTitle('Aktivitas uang'),
                  const SizedBox(height: 12),
                  if (entries.isEmpty)
                    const EmptyState()
                  else
                    BubbleChart(entries: entries.take(12).toList(), onTap: showDetails),
                  const SizedBox(height: 28),
                  const SectionTitle('Pengeluaran per kategori'),
                  const SizedBox(height: 12),
                  if (categoryTotals.isEmpty)
                    const EmptyHint('Belum ada pengeluaran untuk dianalisis.')
                  else
                    ExpenseBreakdown(totals: categoryTotals, total: expense),
                  const SizedBox(height: 28),
                  const SectionTitle('Transaksi terbaru'),
                  const SizedBox(height: 8),
                  if (entries.isEmpty)
                    const EmptyHint('Transaksi yang kamu catat akan muncul di sini.')
                  else
                    ...entries.take(6).map((entry) => ListTile(
                          contentPadding: EdgeInsets.zero,
                          onTap: () => showDetails(entry),
                          leading: CircleAvatar(backgroundColor: (entry.isIncome ? green : coral).withValues(alpha: .13), child: Icon(entry.isIncome ? Icons.south_west_rounded : Icons.north_east_rounded, color: entry.isIncome ? green : coral)),
                          title: Text(entry.category, style: const TextStyle(fontWeight: FontWeight.w800)),
                          subtitle: Text('${entry.account} · ${entry.date}'),
                          trailing: Text('${entry.isIncome ? '+' : '−'}${money(entry.amount)}', style: TextStyle(color: entry.isIncome ? green : coral, fontWeight: FontWeight.w800)),
                        )),
                ]),
              ),
      );
}

class SummaryCard extends StatelessWidget {
  const SummaryCard({super.key, required this.label, required this.amount, required this.color});
  final String label;
  final int amount;
  final Color color;

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(color: color.withValues(alpha: .12), borderRadius: BorderRadius.circular(20)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(label, style: TextStyle(color: color, fontWeight: FontWeight.w700)),
          const SizedBox(height: 8),
          FittedBox(alignment: Alignment.centerLeft, fit: BoxFit.scaleDown, child: Text(money(amount), style: TextStyle(color: color, fontSize: 20, fontWeight: FontWeight.w900))),
        ]),
      );
}

class SectionTitle extends StatelessWidget {
  const SectionTitle(this.title, {super.key});
  final String title;
  @override
  Widget build(BuildContext context) => Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: ink));
}

class EmptyState extends StatelessWidget {
  const EmptyState({super.key});
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.all(24),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(24)),
        child: const Column(children: [Icon(Icons.bubble_chart_rounded, color: green, size: 42), SizedBox(height: 8), Text('Belum ada bubble', style: TextStyle(fontWeight: FontWeight.w900)), Text('Catat transaksi pertama lewat tombol Catat.', textAlign: TextAlign.center, style: TextStyle(color: muted))]),
      );
}

class EmptyHint extends StatelessWidget {
  const EmptyHint(this.message, {super.key});
  final String message;
  @override
  Widget build(BuildContext context) => Padding(padding: const EdgeInsets.symmetric(vertical: 10), child: Text(message, style: const TextStyle(color: muted)));
}

class BubbleChart extends StatelessWidget {
  const BubbleChart({super.key, required this.entries, required this.onTap});
  final List<TransactionEntry> entries;
  final ValueChanged<TransactionEntry> onTap;

  @override
  Widget build(BuildContext context) {
    final maxAmount = entries.map((e) => e.amount).fold<int>(1, (a, b) => a > b ? a : b);
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(24)),
      child: Wrap(alignment: WrapAlignment.center, crossAxisAlignment: WrapCrossAlignment.center, spacing: 8, runSpacing: 8, children: entries.map((entry) {
        final ratio = entry.amount / maxAmount;
        final diameter = 68.0 + 62.0 * math.sqrt(ratio);
        final color = entry.isIncome ? green : coral;
        return Semantics(
          button: true,
          label: '${entry.category}, ${money(entry.amount)}',
          child: InkWell(
            customBorder: const CircleBorder(),
            onTap: () => onTap(entry),
            child: Container(
              width: diameter,
              height: diameter,
              padding: const EdgeInsets.all(7),
              decoration: BoxDecoration(shape: BoxShape.circle, color: color.withValues(alpha: .16), border: Border.all(color: color.withValues(alpha: .75), width: 1.4)),
              child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                Icon(entry.isIncome ? Icons.south_west_rounded : Icons.north_east_rounded, color: color, size: 16),
                Text(entry.category, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w900)),
                Text(compactMoney(entry.amount), maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 10, color: color, fontWeight: FontWeight.w900)),
              ]),
            ),
          ),
        );
      }).toList()),
    );
  }
}

class ExpenseBreakdown extends StatelessWidget {
  const ExpenseBreakdown({super.key, required this.totals, required this.total});
  final Map<String, int> totals;
  final int total;

  @override
  Widget build(BuildContext context) {
    final sorted = totals.entries.toList()..sort((a, b) => b.value.compareTo(a.value));
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(24)),
      child: Column(children: [
        SizedBox(height: 190, child: PieChart(PieChartData(
          sectionsSpace: 3,
          centerSpaceRadius: 48,
          sections: sorted.asMap().entries.map((e) => PieChartSectionData(
            value: e.value.value.toDouble(),
            color: palette[e.key % palette.length],
            radius: 24,
            title: total == 0 ? '' : '${(e.value.value * 100 / total).round()}%',
            titleStyle: const TextStyle(fontSize: 10, color: Colors.white, fontWeight: FontWeight.w900),
          )).toList(),
        ))),
        const SizedBox(height: 10),
        ...sorted.asMap().entries.map((e) => ListTile(
          dense: true,
          contentPadding: EdgeInsets.zero,
          leading: CircleAvatar(radius: 6, backgroundColor: palette[e.key % palette.length]),
          title: Text(e.value.key),
          trailing: Text('${money(e.value.value)}  ·  ${total == 0 ? 0 : (e.value.value * 100 / total).round()}%', style: const TextStyle(fontWeight: FontWeight.w700)),
        )),
      ]),
    );
  }
}

class QuickInputPage extends StatefulWidget {
  const QuickInputPage({super.key});
  @override
  State<QuickInputPage> createState() => _QuickInputPageState();
}

class _QuickInputPageState extends State<QuickInputPage> {
  final amountController = TextEditingController();
  final noteController = TextEditingController();
  String type = 'expense';
  String category = 'Makan';
  String account = 'BCA';
  bool saving = false;

  static const expenseCategories = ['Makan', 'Transport', 'Belanja', 'Tagihan', 'Hiburan', 'Lainnya'];
  static const incomeCategories = ['Gaji', 'Klien', 'Bonus', 'Penjualan', 'Lainnya'];
  static const accounts = ['BCA', 'E-Wallet', 'Cash'];
  List<String> get categories => type == 'income' ? incomeCategories : expenseCategories;

  @override
  void dispose() {
    amountController.dispose();
    noteController.dispose();
    super.dispose();
  }

  Future<void> save() async {
    final amount = int.tryParse(amountController.text.replaceAll(RegExp(r'[^0-9]'), ''));
    if (amount == null || amount <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Masukkan nominal yang valid.')));
      return;
    }
    setState(() => saving = true);
    try {
      final now = DateTime.now();
      await FinanceDatabase.instance.insert(TransactionEntry(
        type: type,
        amount: amount,
        category: category,
        account: account,
        date: '${now.year}-${now.month.toString().padLeft(2, '0')}-${now.day.toString().padLeft(2, '0')}',
        note: noteController.text.trim(),
      ));
      if (mounted) Navigator.of(context).pop(true);
    } catch (_) {
      if (!mounted) return;
      setState(() => saving = false);
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Transaksi gagal disimpan. Coba lagi.')));
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Transaksi baru', style: TextStyle(fontWeight: FontWeight.w900))),
        body: ListView(padding: const EdgeInsets.all(20), children: [
          SegmentedButton<String>(
            segments: const [
              ButtonSegment(value: 'income', label: Text('Masuk'), icon: Icon(Icons.south_west_rounded)),
              ButtonSegment(value: 'expense', label: Text('Keluar'), icon: Icon(Icons.north_east_rounded)),
            ],
            selected: {type},
            onSelectionChanged: (selection) => setState(() { type = selection.first; category = categories.first; }),
          ),
          const SizedBox(height: 28),
          const Text('NOMINAL', style: TextStyle(fontSize: 11, letterSpacing: 1.3, color: muted, fontWeight: FontWeight.w800)),
          const SizedBox(height: 8),
          TextField(
            controller: amountController,
            autofocus: true,
            keyboardType: TextInputType.number,
            style: const TextStyle(fontSize: 32, fontWeight: FontWeight.w900),
            decoration: const InputDecoration(prefixText: 'Rp ', hintText: '0'),
          ),
          const SizedBox(height: 24),
          const Text('Kategori', style: TextStyle(fontWeight: FontWeight.w800)),
          const SizedBox(height: 10),
          Wrap(spacing: 8, runSpacing: 8, children: categories.map((item) => ChoiceChip(label: Text(item), selected: category == item, onSelected: (_) => setState(() => category = item))).toList()),
          const SizedBox(height: 24),
          const Text('Sumber / tujuan dana', style: TextStyle(fontWeight: FontWeight.w800)),
          const SizedBox(height: 10),
          Wrap(spacing: 8, children: accounts.map((item) => ChoiceChip(label: Text(item), selected: account == item, onSelected: (_) => setState(() => account = item))).toList()),
          const SizedBox(height: 24),
          const Text('Catatan (opsional)', style: TextStyle(fontWeight: FontWeight.w800)),
          const SizedBox(height: 8),
          TextField(controller: noteController, textCapitalization: TextCapitalization.sentences, decoration: const InputDecoration(hintText: 'Misalnya: makan siang')),
          const SizedBox(height: 30),
          FilledButton.icon(
            onPressed: saving ? null : save,
            style: FilledButton.styleFrom(backgroundColor: ink, foregroundColor: Colors.white, minimumSize: const Size.fromHeight(54)),
            icon: const Icon(Icons.check_rounded),
            label: Text(saving ? 'Menyimpan...' : 'Simpan transaksi', style: const TextStyle(fontWeight: FontWeight.w800)),
          ),
        ]),
      );
}

Widget detailRow(String label, String value) => Padding(
      padding: const EdgeInsets.symmetric(vertical: 7),
      child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text(label, style: const TextStyle(color: muted)), Flexible(child: Text(value, textAlign: TextAlign.end, style: const TextStyle(fontWeight: FontWeight.w800, color: ink)))]),
    );
