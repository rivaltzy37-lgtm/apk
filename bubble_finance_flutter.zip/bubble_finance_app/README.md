# Bubble Finance (Flutter starter)

A minimalist finance-tracker starter app with local SQLite storage, income/expense summaries, transaction bubbles, an expense chart, and add/delete transaction flows.

## Build an APK without a PC

You can do this from your Android phone using a browser; the actual build runs on GitHub's cloud servers.

1. Create/sign in to a GitHub account in your phone browser.
2. Create a **public or private repository** (for example `bubble-finance`).
3. Upload the contents of this project to the repository, keeping the `.github/workflows/build-apk.yml` file and its folders intact. On GitHub mobile web, use **Add file → Upload files**; if hidden files are awkward to upload, use Termux with `git` instead.
4. Open the repository's **Actions** tab and select **Build Bubble Finance APK**.
5. Tap **Run workflow** (or push to `main` to trigger it automatically) and wait for the job to finish.
6. Open the completed workflow run, scroll to **Artifacts**, and download `bubble-finance-apk`. Extract it to get `app-release.apk`.
7. Open the APK on your phone and allow installation from that source if Android asks.

The workflow generates the Android platform folder and builds the APK on a cloud runner. GitHub account/repository and Actions availability or usage limits may apply.

## Build locally (if Flutter is installed)

```bash
flutter create . --platforms=android
flutter pub get
flutter run
```

## Notes

- This is starter source code, not a prebuilt APK.
- Transactions are stored locally on the device in SQLite. There is no cloud sync/login/backup yet.
- Account choices and categories are starter lists, not a full account-management system.
- The project has not been compiled in this authoring environment.
